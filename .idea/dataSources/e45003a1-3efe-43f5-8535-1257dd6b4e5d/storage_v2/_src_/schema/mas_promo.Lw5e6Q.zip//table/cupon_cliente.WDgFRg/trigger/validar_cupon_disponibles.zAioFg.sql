create definer = root@localhost trigger validar_cupon_disponibles
    before insert
    on cupon_cliente
    for each row
BEGIN
    DECLARE cant_disp INT DEFAULT 0;
    SET cant_disp = (SELECT cant_disp FROM cupon WHERE code_cupon = NEW.fk_code_cupon);

    IF (cant_disp - 1 < 0) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'CUPONES NO DISPONIBLES';
    END IF;
END;

